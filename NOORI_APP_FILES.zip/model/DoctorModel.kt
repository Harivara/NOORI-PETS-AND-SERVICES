package com.example.noori_app.model

data class DoctorModel(
    val DoctorName: String?="",
    val DoctorEmail: String?="",
    val DoctorPhoneNumber: String?="",
    val Doctorvillage:String?="",
    val Doctorstate:String?="",
    val Doctorcity:String?="",
    val Doctorpincode:String?=""

)
