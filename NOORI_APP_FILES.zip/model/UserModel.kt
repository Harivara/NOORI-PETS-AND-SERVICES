package com.example.noori_app.model

data class UserModel(
        val userName: String?="",
        val userEmail: String?="",
        val userPhoneNumber: String?="",
        val village:String?="",
        val state:String?="",
        val city:String?="",
        val pincode:String?=""
)
