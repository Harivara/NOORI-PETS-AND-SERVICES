package com.example.noori_app.model

class CategoryModel (
    var cate : String ? = "",
    var img : String ? = ""
)