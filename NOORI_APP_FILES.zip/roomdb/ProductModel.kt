package com.example.noori_app

import androidx.room.ColumnInfo
import io.reactivex.annotations.NonNull
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductModel(
    @PrimaryKey
    @NonNull
    val productId : String,
    @ColumnInfo("productName")
    val productName : String?="",
    @ColumnInfo("productImage")
    val productImage : String?="",
    @ColumnInfo("productSp")
    val productSp : String?="",


    )
