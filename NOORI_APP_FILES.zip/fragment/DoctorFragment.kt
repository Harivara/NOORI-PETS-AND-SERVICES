package com.example.noori_app.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.noori_app.R
import com.example.noori_app.databinding.FragmentDoctorBinding
import com.example.noori_app.databinding.FragmentProfileBinding
import com.google.firebase.auth.FirebaseAuth


class DoctorFragment : Fragment() {


    private lateinit var binding: FragmentDoctorBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentDoctorBinding.inflate(layoutInflater)



        return binding.root

    }


}