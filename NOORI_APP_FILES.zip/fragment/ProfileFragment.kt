package com.example.noori_app.fragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.noori_app.R
import com.example.noori_app.activity.LoginActivity
//import com.example.noori_app.activity.LoginActivity
import com.example.noori_app.databinding.FragmentProfileBinding
import com.google.firebase.auth.FirebaseAuth


class ProfileFragment : Fragment() {


    private lateinit var binding: FragmentProfileBinding
    private lateinit var auth: FirebaseAuth
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        // Inflate the layout for this fragment
        auth = FirebaseAuth.getInstance()
        binding = FragmentProfileBinding.inflate(layoutInflater)

        binding.profilePic.text ="Harivaraprasad"
        binding.emailid.text ="Harivara963@gmail.com"
        binding.btnLogout.setOnClickListener {
            auth.signOut()
            val intent = Intent(this@ProfileFragment. requireContext(), LoginActivity::class.java)
            startActivity(intent)
            Toast.makeText(requireContext(), "Logout Successful", Toast.LENGTH_LONG).show()
        }
        return binding.root

    }
}

