package com.example.noori_app.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Adapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.noori_app.R
import com.example.noori_app.activity.CategoryActivity
import com.example.noori_app.databinding.LayoutCategoryItemBinding
import com.example.noori_app.model.CategoryModel



class CategoryAdapter(var context: Context, val list: ArrayList<CategoryModel>) :
    RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder>() {

    inner class CategoryViewHolder(vi : View): RecyclerView.ViewHolder(vi){
    var binding = LayoutCategoryItemBinding.bind(vi)}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        return CategoryViewHolder(LayoutInflater.from(context).inflate(R.layout.layout_category_item, parent ,false))    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        holder.binding.catlayText.text = list[position].cate
        Glide.with(context).load(list[position].img).into(holder.binding.imageView)

        holder.itemView.setOnClickListener{
            val intent = Intent(context , CategoryActivity::class.java)
            intent.putExtra("cate" ,list[position].cate)
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return list.size
     }
}