package com.example.noori_app.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.noori_app.activity.ProductDetailActivity
import com.example.noori_app.databinding.LayoutDoctorsBinding
//import com.example.noori_app.activity.ProductDetailActivity
import com.example.noori_app.databinding.LayoutProductItemBinding
import com.example.noori_app.model.AddProductModel
import com.example.noori_app.model.DoctorModel

import kotlinx.coroutines.NonDisposableHandle.parent

class DoctorAdapter(val context: Context, val list: ArrayList<DoctorModel>):
    RecyclerView.Adapter<DoctorAdapter.DoctorViewHolder>() {
    inner class DoctorViewHolder(val binding: LayoutDoctorsBinding):
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DoctorViewHolder {
        val binding =LayoutDoctorsBinding.inflate(LayoutInflater.from(context), parent,false)
        return DoctorViewHolder(binding)
    }
    override fun onBindViewHolder(holder: DoctorViewHolder, position: Int) {
        TODO("Not yet implemented")
    }
    override fun getItemCount(): Int {
        return list.size

    }


}