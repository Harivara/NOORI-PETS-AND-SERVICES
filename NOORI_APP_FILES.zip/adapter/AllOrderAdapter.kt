package com.example.noori_app.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Adapter
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.example.noori_app.databinding.AllOrdersItemLayoutBinding
import com.example.noori_app.model.AllOrderModel

import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import javax.annotation.meta.When

class AllOrderAdapter(val list: ArrayList<AllOrderModel>, val context: Context)
    :RecyclerView.Adapter<AllOrderAdapter.AllOrderViewHolder>()
{

    inner class AllOrderViewHolder(val binding: AllOrdersItemLayoutBinding)
            : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AllOrderViewHolder {
        return AllOrderViewHolder(
            AllOrdersItemLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: AllOrderViewHolder, position: Int) {
            holder.binding.productTitle.text= list[position].name
            holder.binding.prodPrice.text= list[position].price


        when(list[position].status){
            "Ordered"->{
                holder.binding.prodStatus.text= "Ordered"
            }
            "Dispatched"->{
                holder.binding.prodStatus.text= "Dispatched"

            }
            "Delivered"-> {
                holder.binding.prodStatus.text= "Delivered"

            }

            "Canceled"->{
                holder.binding.prodStatus.text= "Canceled"


            }
        }
    }



    override fun getItemCount(): Int {
        return list.size   }
}