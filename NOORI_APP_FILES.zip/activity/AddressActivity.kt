package com.example.noori_app.activity

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContentProviderCompat.requireContext
import com.bumptech.glide.Glide
import com.example.noori_app.R
import com.example.noori_app.databinding.ActivityAddressBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class AddressActivity : AppCompatActivity() {
     private lateinit var binding: ActivityAddressBinding
    private lateinit var preferences :SharedPreferences
    private lateinit var totalCost :String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddressBinding.inflate(layoutInflater)
        preferences=this.getSharedPreferences("user", MODE_PRIVATE)


        totalCost=intent.getStringExtra("totalCost")!!

        loadUserInfo()

    setContentView(binding.root)

            binding.proceed.setOnClickListener{
                validatedata(
                    binding.usernameEt.text.toString(),
                    binding.mobile.text.toString(),
                    binding.Pincode.text.toString(),
                    binding.State.text.toString(),
                    binding.village.text.toString(),
                    binding.City.text.toString()
                )
            }
    }

    private fun validatedata(name: String, number: String, pincode: String, state: String, village: String, city: String) {
                if(state.isEmpty() || number.isEmpty() || name.isEmpty()){
                    Toast.makeText(this, "Please fill all Fields", Toast.LENGTH_SHORT).show()
                }
        else{
            storeData(pincode,state,village,city)
                }
    }

    private fun storeData(pincode: String, state: String, village: String, city: String) {
            val map = hashMapOf<String,Any>()
                map["village"]=village
                map["pincode"]=pincode
                map["city"]=city
                map["state"]=state

        Firebase.firestore.collection("users")
            .document(preferences.getString("number","1")!!)
            .update(map).addOnSuccessListener {

                val b=Bundle()
                b.putStringArrayList("productIds",intent.getStringArrayListExtra("productIds"))
                b.putString("totalCost",totalCost)
                val intent = Intent(this , CheckoutActivity::class.java)
                intent.putExtras(b)

                Toast.makeText(this, "Data Updated", Toast.LENGTH_SHORT).show()
                startActivity(intent)
            }
            .addOnFailureListener {
                Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show()
                Toast.makeText(this, "Data not Updated", Toast.LENGTH_SHORT).show()

            }
    }

    private fun loadUserInfo() {

        Firebase.firestore.collection("users")
            .document(preferences.getString("number","9182473711 ")!!)
            .get().addOnSuccessListener {
                binding.usernameEt.setText(it.getString("userName"))
                binding.mobile.setText(it.getString("userPhoneNumber"))
                binding.City.setText(it.getString("city"))
                binding.Pincode.setText(it.getString("pincode"))
                binding.State.setText(it.getString("state"))
                binding.village.setText(it.getString("village"))
            }
            .addOnFailureListener {
                Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show()
            }
    }


}

