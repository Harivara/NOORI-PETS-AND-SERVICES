package com.example.noori_app.activity

import android.content.Intent
import android.os.Binder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.noori_app.R
import com.example.noori_app.databinding.ActivityRegisterBinding
import com.example.noori_app.model.UserModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView( binding.root)

        binding.already.setOnClickListener{
            openlogin()
    }
        binding.btnRegister.setOnClickListener{
            validateUser()
        }
    }

    private fun validateUser() {
        if(binding.etUsername.text!!.isEmpty() || binding.mobileNumber.text!!.isEmpty()){
            Toast.makeText(this, "Please fill all feild", Toast.LENGTH_SHORT).show()
        }
        else{
            storeData()
        }
    }

    private fun storeData() {
        val builder =AlertDialog.Builder(this)
            .setTitle("Loading...")
            .setMessage("Please Wait")
            .setCancelable(false)
            .create()
        builder.show()

        val preferences = this.getSharedPreferences("user", MODE_PRIVATE)
        val editor = preferences.edit()
        editor.putString("number",binding.mobileNumber.text.toString())
        editor.putString("name",binding.etUsername.text.toString())
        editor.apply()

        val data = UserModel(userName = binding.etUsername.text.toString(),
        userPhoneNumber = binding.mobileNumber.text.toString())

        Firebase.firestore.collection("users").document(binding.mobileNumber.text.toString())
            .set(data).addOnSuccessListener {
                Toast.makeText(this, "User Registerd", Toast.LENGTH_SHORT).show()
                builder.dismiss()
                openlogin()

            }

            .addOnFailureListener {
                Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show()
                builder.dismiss()

            }
    }

    private fun openlogin() {
        startActivity(Intent(this,LoginActivity::class.java))
        finish()    }
}