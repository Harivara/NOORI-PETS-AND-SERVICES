package com.example.noori_app.activity

import android.content.Context.MODE_PRIVATE
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleCoroutineScope
import androidx.lifecycle.lifecycleScope
import com.denzcoskun.imageslider.constants.ScaleTypes
import com.denzcoskun.imageslider.models.SlideModel
import com.example.noori_app.MainActivity
import com.example.noori_app.ProductModel
import com.example.noori_app.databinding.ActivityProductDetailBinding
import com.example.noori_app.fragment.HomeFragment
import com.example.noori_app.roomdb.AppDatabase
import com.example.noori_app.roomdb.ProductDao


import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ProductDetailActivity : AppCompatActivity() {
     private lateinit var binding: ActivityProductDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductDetailBinding.inflate(layoutInflater)

        getProductDetails(intent.getStringExtra("id"))
        setContentView(binding.root)
    }

    private fun getProductDetails(proId: String?) {
    Firebase.firestore.collection("Products")
        .document(proId!!).get().addOnSuccessListener {
            val list= it.get("productImages") as ArrayList<String>
            val name = it.getString("productName")
            val productSp = it.getString("productSp")
            val productDec = it.getString("productDescription")
            binding.textView3.text = name
            binding.textView4.text = "Product Price ${productSp}"
            binding.textView8.text = productDec

            val slidelist = ArrayList<SlideModel>()

            for(data in list){
                slidelist.add(SlideModel(data, ScaleTypes.FIT))
            }


            cartAction(proId,name,productSp,it.getString("productCoverImg"))

            binding.imageSlider.setImageList(slidelist)
        }
        .addOnFailureListener {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT)
        }
    }

    private fun cartAction(proId: String, name: String?,productSp: String?,coverImg:String?) {

        val productDao = AppDatabase.getInstance(this).productDao()

         if(productDao.isExit(proId)!=null) {
            binding.textView9.text = "Go To Cart"
        }
        else{
            binding.textView9.text ="Add To Cart"
        }

        binding.textView9.setOnClickListener{
            if(productDao.isExit(proId)!=null) {
                openCart()
            }
            else{
                addToCart(productDao,proId,name,productSp,coverImg)
            }
        }
    }



    private fun addToCart(
        productDao: ProductDao,
        proId: String,
        name:String?,
        productSp:String?,
        coverImg:String?
    ) {

        val data = ProductModel(proId,name,coverImg,productSp)
        lifecycleScope.launch(Dispatchers.IO){
            productDao.insertProduct(data)
            binding.textView9.text = "Go To Cart"

        }
    }

    private fun openCart() {
        val preference = this.getSharedPreferences("info", MODE_PRIVATE)
        val editor = preference.edit()
        editor.putBoolean("isCart", true)
        editor.apply()

       startActivity(Intent(this,MainActivity::class.java))
            finish()
        }
    }
