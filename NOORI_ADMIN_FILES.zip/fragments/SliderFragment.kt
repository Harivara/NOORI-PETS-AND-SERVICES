package com.example.noorie_admin.fragments

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.example.noorie_admin.R
import com.example.noorie_admin.databinding.ActivityMainBinding
import com.example.noorie_admin.databinding.FragmentSliderBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import java.util.*



class SliderFragment : Fragment() {
 private lateinit var binding: FragmentSliderBinding
 private  var imageurl : Uri? =null
    private  lateinit var dailog : Dialog

 private var launchGalleryActivity = registerForActivityResult(
     ActivityResultContracts.StartActivityForResult()
 ){
     if(it.resultCode ==Activity.RESULT_OK){
         imageurl = it.data!!.data
         binding.imageView.setImageURI(imageurl)

     }
 }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        binding = FragmentSliderBinding.inflate(layoutInflater)
        // Inflate the layout for this fragment
        dailog = Dialog(requireContext())
        dailog.setContentView(R.layout.progress_layout)
        dailog.setCancelable(false)

        binding.apply {
            imageView.setOnClickListener{
                val intent = Intent("android.intent.action.GET_CONTENT")
                intent.type = "image/*"
                launchGalleryActivity.launch(intent)
            }
            button.setOnClickListener{
                if(imageurl!= null){
                    Upload_img(imageurl!!)
                }
                else{
                    Toast.makeText(requireContext(), "Please select the image", Toast.LENGTH_SHORT).show()
                }
            }
        }
        return binding.root

    }

    private fun Upload_img(imguri: Uri) {
        dailog.show()
        val fileName = UUID.randomUUID().toString()+".jpg"
        val refstorage = FirebaseStorage.getInstance().reference.child("slider/$fileName")
        refstorage.putFile(imguri)
            .addOnSuccessListener {
                it.storage.downloadUrl.addOnSuccessListener { imaaage ->
                    storeData(imaaage.toString())
                }
            }

            .addOnFailureListener { 
                dailog.dismiss()
                Toast.makeText(requireContext(), "Something went wrong with storage.", Toast.LENGTH_SHORT).show()
            }
    }

    private fun storeData(imaaaaage: String) {
        val db = Firebase.firestore
        val data = hashMapOf<String, Any>(
            "img" to imaaaaage
        )
        db.collection("slider").document("item").set(data)
            .addOnSuccessListener {
                dailog.dismiss()
                Toast.makeText(requireContext(), "Slider Updated", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener{
                dailog.dismiss()
                Toast.makeText(requireContext(), "Something went wrong", Toast.LENGTH_SHORT).show()

            }
    }

}