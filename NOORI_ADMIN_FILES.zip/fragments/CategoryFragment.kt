package com.example.noorie_admin.fragments

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.example.noorie_admin.R
import com.example.noorie_admin.adapter.CategoryAdapter
import com.example.noorie_admin.databinding.FragmentCategoryBinding
import com.example.noorie_admin.model.CategoryModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import java.util.*
import kotlin.collections.ArrayList

class CategoryFragment : Fragment() {
    private lateinit var binding: FragmentCategoryBinding
    private  var imageurl : Uri? =null
    private  lateinit var dailog : Dialog


    private var launchGalleryActivity = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ){
        if(it.resultCode == Activity.RESULT_OK){
            imageurl = it.data!!.data
            binding.imageView.setImageURI(imageurl)
        }
    }
        override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        // Inflate the layout for this fragment
            binding = FragmentCategoryBinding.inflate(layoutInflater)
            dailog = Dialog(requireContext())
            dailog.setContentView(R.layout.progress_layout)
            dailog.setCancelable(false)
            getData()
            binding.apply {
                imageView.setOnClickListener{
                    val intent = Intent("android.intent.action.GET_CONTENT")
                    intent.type = "image/*"
                    launchGalleryActivity.launch(intent)
                }
                button6.setOnClickListener {
                    Validatedata(binding.CategoName.text.toString())
                }
            }
        return binding.root
    }

    private fun getData(){
        val list=ArrayList<CategoryModel>()
        Firebase.firestore.collection("Category")
            .get().addOnSuccessListener {
                list.clear()
                for(doc in it.documents){
                    val data =doc.toObject(CategoryModel::class.java)
                    list.add(data!!)
                }
                binding.categorRec.adapter =CategoryAdapter(requireContext(),list)
            }
    }
    private fun Validatedata(ca_name: String) {
        if(ca_name.isEmpty()){
            Toast.makeText(requireContext(), "Please enter Catogory name", Toast.LENGTH_SHORT).show()
        }
        else if(imageurl==null){
            Toast.makeText(requireContext(), "Please select Image", Toast.LENGTH_SHORT).show()
        }
        else{
            Upload_img(ca_name)
        }
    }
    private fun Upload_img(ca_name: String) {
        dailog.show()
        val fileName = UUID.randomUUID().toString()+".jpg"
        val refstorage = FirebaseStorage.getInstance().reference.child("Category/$fileName")
        refstorage.putFile(imageurl!!)
            .addOnSuccessListener {
                it.storage.downloadUrl.addOnSuccessListener { imaaage ->
                    storeData(ca_name,imaaage.toString())
                }
            }

            .addOnFailureListener {
                dailog.dismiss()
                Toast.makeText(requireContext(), "Something went wrong with storage.", Toast.LENGTH_SHORT).show()
            }
    }

    private fun storeData(categoryname: String, imaaaaage: String) {
        val db = Firebase.firestore
        val data = hashMapOf<String, Any>(
            "img" to imaaaaage,
            "cate" to categoryname

        )
        db.collection("Category").add(data)
            .addOnSuccessListener {
                dailog.dismiss()
                binding.imageView.setImageDrawable(resources.getDrawable(R.drawable.image_prev))
                binding.CategoName.text=null
                getData()
                Toast.makeText(requireContext(), "Category added", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener{
                dailog.dismiss()
                Toast.makeText(requireContext(), "Something went wrong", Toast.LENGTH_SHORT).show()

            }
    }

}