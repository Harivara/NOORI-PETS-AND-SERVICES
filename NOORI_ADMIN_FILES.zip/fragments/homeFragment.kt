package com.example.noorie_admin.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.noorie_admin.AllOrderActivity
import com.example.noorie_admin.R
import com.example.noorie_admin.databinding.ActivityAllOrderBinding
import com.example.noorie_admin.databinding.FragmentHomeBinding
import com.google.firebase.auth.FirebaseAuth


class homeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding
    private lateinit var auth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {

        // Inflate the layout for this fragment
        binding = FragmentHomeBinding.inflate(layoutInflater)
        binding.button.setOnClickListener{
            findNavController().navigate(R.id.action_homeFragment_to_categoryFragment)
        }
        binding.button2.setOnClickListener{
            findNavController().navigate(R.id.action_homeFragment_to_productFragment)
        }
        binding.button3.setOnClickListener{
            findNavController().navigate(R.id.action_homeFragment_to_sliderFragment)
    }
        binding.button4.setOnClickListener{
            startActivity(Intent(requireContext(), AllOrderActivity::class.java))
        }

        return binding.root
    }
}