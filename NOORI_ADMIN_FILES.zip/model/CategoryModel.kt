package com.example.noorie_admin.model

class CategoryModel (
    var cate : String ? = "",
    var img : String ? = ""
)